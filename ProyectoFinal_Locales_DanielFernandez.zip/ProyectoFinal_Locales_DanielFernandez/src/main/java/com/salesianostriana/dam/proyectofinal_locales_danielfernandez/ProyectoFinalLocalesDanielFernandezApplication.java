package com.salesianostriana.dam.proyectofinal_locales_danielfernandez;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoFinalLocalesDanielFernandezApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoFinalLocalesDanielFernandezApplication.class, args);
	}

}
