package com.salesianostriana.dam.proyectofinal_locales_danielfernandez.servicio;

import java.util.List;

import org.springframework.stereotype.Service;

import com.salesianostriana.dam.proyectofinal_locales_danielfernandez.model.Local;
import com.salesianostriana.dam.proyectofinal_locales_danielfernandez.repository.LocalRepository;
import com.salesianostriana.dam.proyectofinal_locales_danielfernandez.servicio.base.BaseService;

/**
 * 
 * @author DFB
 *
 */

@Service
public class LocalService extends BaseService<Local,Long,LocalRepository>{

	/**
	 * 
	 * @param repo
	 */
	public LocalService(LocalRepository repo) {
		super(repo);
	}
	
	/**
	 * Envoltorio para el método del repositorio
	 * @return una lista de locales que están en venta
	 */
	public List<Local> filtrarPorCompra(){
		return repositorio.findLocalByEnVentaIsTrue();
	}
	
	/**
	 * Envoltorio para el método del reporitorio
	 * @return una lista de locales en alquiler
	 */
	public List<Local> filtrarPorAlquiler(){
		return repositorio.findLocalByEnVentaIsFalse();
	}

}
