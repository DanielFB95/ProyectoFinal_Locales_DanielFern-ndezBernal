package com.salesianostriana.dam.proyectofinal_locales_danielfernandez.model;

import java.util.List;

public class DataMaster {
	
	public static List<String> tiposInmuebles(){
		return List.of("Casa","Piso","Chalet","Trastero");
	}
	
	public static List<String> cantidades(){
		return List.of("0","1","2","3","4 o más");
	}

}
