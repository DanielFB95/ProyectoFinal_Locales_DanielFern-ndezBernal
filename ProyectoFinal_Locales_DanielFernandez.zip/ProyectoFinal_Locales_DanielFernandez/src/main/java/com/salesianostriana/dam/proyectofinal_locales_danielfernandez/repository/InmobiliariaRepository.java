package com.salesianostriana.dam.proyectofinal_locales_danielfernandez.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.salesianostriana.dam.proyectofinal_locales_danielfernandez.model.Inmobiliaria;

/**
 * 
 * @author DFB
 *
 */

public interface InmobiliariaRepository extends JpaRepository<Inmobiliaria,Long>{

}
