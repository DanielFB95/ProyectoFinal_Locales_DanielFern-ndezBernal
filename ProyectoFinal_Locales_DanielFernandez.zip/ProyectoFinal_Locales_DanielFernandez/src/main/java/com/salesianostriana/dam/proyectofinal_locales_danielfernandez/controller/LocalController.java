package com.salesianostriana.dam.proyectofinal_locales_danielfernandez.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.salesianostriana.dam.proyectofinal_locales_danielfernandez.model.DataMaster;
import com.salesianostriana.dam.proyectofinal_locales_danielfernandez.model.Local;
import com.salesianostriana.dam.proyectofinal_locales_danielfernandez.servicio.InmobiliariaService;
import com.salesianostriana.dam.proyectofinal_locales_danielfernandez.servicio.LocalService;

/**
 * 
 * @author DFB
 *
 */

@Controller
public class LocalController {

	private LocalService localService;
	private InmobiliariaService inmoService;
	

	public LocalController(LocalService servicio, InmobiliariaService servicioInmo) {
		localService = servicio;
		inmoService = servicioInmo;
	}
	
	
	/**
	 * Método/petición que sirve para pintar por pantalla la página de contenido de un producto en concreto
	 * @param id
	 * @param model
	 * @return
	 */
	@GetMapping("/local/{id}")
	public String unLocal(@PathVariable("id")Long id, Model model) {
		Local local = localService.findById(id);
		model.addAttribute("local", local);
		return "content";
	}
	
	/**
	 * Método/petición que pinta la pantalla principal con todos los locales
	 * @param model
	 * @return
	 */
	@GetMapping("/index")
	public String showIndex(Model model) {
		model.addAttribute("locales", localService.findAll());
		return "index";
	}
	
	/**
	 * Método/petición que pinta por pantalla el formulario para dar de alta un nuevo local
	 * @param model
	 * @return
	 */
	@GetMapping("/form")
	public String showForm(Model model) {
		
		model.addAttribute("inmobiliarias", inmoService.findAll());
		model.addAttribute("local", new Local());
		
		return "form";
	}
	
	/**
	 * Método/petición que sirve para borrar un local y vuelve a pintar la pantalla principal
	 * @param localId
	 * @param model
	 * @return
	 */
	@GetMapping("/delete/{id}")
	public String deleteLocal(@PathVariable("id")Long localId, Model model) {
		localService.deleteById(localId);
		return "redirect:/index";
	}
	
	/**
	 * Método/petición que pinta el formulario con los datos de un local en concreto para poder modificarlo
	 * @param id
	 * @param model
	 * @return
	 */
	@GetMapping("/edit/{id}")
	public String editLocal(@PathVariable("id") Long id,Model model) {
		Local local = localService.findById(id);
		
		model.addAttribute("inmobiliarias", inmoService.findAll());
		model.addAttribute("local", local);
		return "form";
	}
	
	/**
	 * Método/petición que agrega un nuevo local y vuelve a pintar la pantalla principal
	 * @param local
	 * @param model
	 * @return
	 */
	@PostMapping("/addLocal")
	public String guardar(@ModelAttribute("local") Local local,Model model){
		local.setFechaAltaLocal(LocalDate.now());
		localService.save(local);
		return "redirect:/index";
	}
	
	/**
	 * Método/petición que pinta la página principal con los locales que están en venta
	 * @param model
	 * @return
	 */
	@GetMapping("/index/venta")
	public String showEnVenta(Model model) {
		model.addAttribute("locales", localService.filtrarPorCompra());
		return "index";
	}
	
	/**
	 * Método/petición que pinta la página principal con los locales que están en alquiler
	 * @param model
	 * @return
	 */
	@GetMapping("/index/alquiler")
	public String showEnAlquiler(Model model) {
		model.addAttribute("locales", localService.filtrarPorAlquiler());
		return "index";
	}
	
	@ModelAttribute("tipos")
	public List<String> tiposInmuebles(){
		return DataMaster.tiposInmuebles();
	}
	
	@ModelAttribute("cantidades")
	public List<String> cantidades(){
		return DataMaster.cantidades();
	}
	
	
	
	
	
	
		
	
}
