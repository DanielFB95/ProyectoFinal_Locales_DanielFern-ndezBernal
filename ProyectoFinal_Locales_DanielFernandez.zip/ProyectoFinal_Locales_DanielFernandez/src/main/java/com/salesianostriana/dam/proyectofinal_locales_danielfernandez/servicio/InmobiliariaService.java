package com.salesianostriana.dam.proyectofinal_locales_danielfernandez.servicio;

import org.springframework.stereotype.Service;

import com.salesianostriana.dam.proyectofinal_locales_danielfernandez.model.Inmobiliaria;
import com.salesianostriana.dam.proyectofinal_locales_danielfernandez.repository.InmobiliariaRepository;
import com.salesianostriana.dam.proyectofinal_locales_danielfernandez.servicio.base.BaseService;

/**
 * 
 * @author DFB
 */

@Service
public class InmobiliariaService extends BaseService<Inmobiliaria,Long, InmobiliariaRepository>{

	/**
	 * 
	 * @param repo
	 */
	public InmobiliariaService(InmobiliariaRepository repo) {
		super(repo);
	}

}
