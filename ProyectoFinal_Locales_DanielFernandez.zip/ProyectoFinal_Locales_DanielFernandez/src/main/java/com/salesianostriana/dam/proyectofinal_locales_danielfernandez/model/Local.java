package com.salesianostriana.dam.proyectofinal_locales_danielfernandez.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Clase que modela los datos de un local
 * @author DFB
 *
 */

@Data
@NoArgsConstructor
@Entity
public class Local {
	
	@Id
	@GeneratedValue
	private long id;
	
	private String ciudad,localidad,tipo,direccion,nombrePropietario,telefonoContacto,emailContacto,imagen, numServicios,numHabitaciones;
	
	@Lob
	private String descripcion;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate fechaEdificacion,fechaAltaLocal;
	private double superficie,precioAlquilerMes,precioCompra;
	private boolean enVenta;//Todo lo que no este en  venta, se entiende que sólo se alquilará
	
	@ManyToOne
	private Inmobiliaria inmo;

	/**
	 * 
	 * @param ciudad
	 * @param localidad
	 * @param tipo
	 * @param direccion
	 * @param nombrePropietario
	 * @param telefonoContacto
	 * @param emailContacto
	 * @param imagen
	 * @param numServicios
	 * @param numHabitaciones
	 * @param descripcion
	 * @param fechaEdificacion
	 * @param fechaAltaLocal
	 * @param superficie
	 * @param precioAlquilerMes
	 * @param precioCompra
	 * @param enVenta
	 * @param inmo
	 */

	public Local(String ciudad, String localidad, String tipo, String direccion, String nombrePropietario,
			String telefonoContacto, String emailContacto, String imagen, String numServicios, String numHabitaciones,
			String descripcion, LocalDate fechaEdificacion, LocalDate fechaAltaLocal, double superficie,
			double precioAlquilerMes, double precioCompra, boolean enVenta, Inmobiliaria inmo) {
		super();
		this.ciudad = ciudad;
		this.localidad = localidad;
		this.tipo = tipo;
		this.direccion = direccion;
		this.nombrePropietario = nombrePropietario;
		this.telefonoContacto = telefonoContacto;
		this.emailContacto = emailContacto;
		this.imagen = imagen;
		this.numServicios = numServicios;
		this.numHabitaciones = numHabitaciones;
		this.descripcion = descripcion;
		this.fechaEdificacion = fechaEdificacion;
		this.fechaAltaLocal = fechaAltaLocal;
		this.superficie = superficie;
		this.precioAlquilerMes = precioAlquilerMes;
		this.precioCompra = precioCompra;
		this.enVenta = enVenta;
		this.inmo = inmo;
	}

	/**
	 * 
	 * @param ciudad
	 * @param localidad
	 * @param tipo
	 * @param direccion
	 * @param nombrePropietario
	 * @param telefonoContacto
	 * @param emailContacto
	 * @param imagen
	 * @param numServicios
	 * @param numHabitaciones
	 * @param descripcion
	 * @param fechaEdificacion
	 * @param fechaAltaLocal
	 * @param superficie
	 * @param precioCompra
	 * @param enVenta
	 * @param inmo
	 */
	public Local(String ciudad, String localidad, String tipo, String direccion, String nombrePropietario,
			String telefonoContacto, String emailContacto, String imagen, String numServicios, String numHabitaciones,
			String descripcion, LocalDate fechaEdificacion, LocalDate fechaAltaLocal, double superficie,
			double precioCompra, boolean enVenta, Inmobiliaria inmo) {
		super();
		this.ciudad = ciudad;
		this.localidad = localidad;
		this.tipo = tipo;
		this.direccion = direccion;
		this.nombrePropietario = nombrePropietario;
		this.telefonoContacto = telefonoContacto;
		this.emailContacto = emailContacto;
		this.imagen = imagen;
		this.numServicios = numServicios;
		this.numHabitaciones = numHabitaciones;
		this.descripcion = descripcion;
		this.fechaEdificacion = fechaEdificacion;
		this.fechaAltaLocal = fechaAltaLocal;
		this.superficie = superficie;
		this.precioCompra = precioCompra;
		this.enVenta = enVenta;
		this.inmo = inmo;
	}

	/**
	 * 
	 * @param id
	 * @param ciudad
	 * @param localidad
	 * @param tipo
	 * @param direccion
	 * @param nombrePropietario
	 * @param telefonoContacto
	 * @param emailContacto
	 * @param imagen
	 * @param numServicios
	 * @param numHabitaciones
	 * @param descripcion
	 * @param fechaEdificacion
	 * @param fechaAltaLocal
	 * @param superficie
	 * @param precioAlquilerMes
	 * @param enVenta
	 * @param inmo
	 */
	public Local(long id, String ciudad, String localidad, String tipo, String direccion, String nombrePropietario,
			String telefonoContacto, String emailContacto, String imagen, String numServicios, String numHabitaciones,
			String descripcion, LocalDate fechaEdificacion, LocalDate fechaAltaLocal, double superficie,
			double precioAlquilerMes, boolean enVenta, Inmobiliaria inmo) {
		super();
		this.id = id;
		this.ciudad = ciudad;
		this.localidad = localidad;
		this.tipo = tipo;
		this.direccion = direccion;
		this.nombrePropietario = nombrePropietario;
		this.telefonoContacto = telefonoContacto;
		this.emailContacto = emailContacto;
		this.imagen = imagen;
		this.numServicios = numServicios;
		this.numHabitaciones = numHabitaciones;
		this.descripcion = descripcion;
		this.fechaEdificacion = fechaEdificacion;
		this.fechaAltaLocal = fechaAltaLocal;
		this.superficie = superficie;
		this.precioAlquilerMes = precioAlquilerMes;
		this.enVenta = enVenta;
		this.inmo = inmo;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	

}
