package com.salesianostriana.dam.proyectofinal_locales_danielfernandez.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.salesianostriana.dam.proyectofinal_locales_danielfernandez.model.Local;

/**
 * 
 * @author DFB
 *
 */

public interface LocalRepository extends JpaRepository<Local,Long>{

	/**Filtrar los locales por el campo enVenta
	 * @return una lista de locales que están a la venta
	 */
	List<Local> findLocalByEnVentaIsTrue();
	
	
	/**Filtrar los locales en alquiler
	 * @return una lista de locales que no están a la venta por lo que estarán en alquiler
	 */
	List<Local> findLocalByEnVentaIsFalse();
}
