package com.salesianostriana.dam.proyectofinal_locales_danielfernandez;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.salesianostriana.dam.proyectofinal_locales_danielfernandez.model.Inmobiliaria;
import com.salesianostriana.dam.proyectofinal_locales_danielfernandez.model.Local;
import com.salesianostriana.dam.proyectofinal_locales_danielfernandez.servicio.InmobiliariaService;
import com.salesianostriana.dam.proyectofinal_locales_danielfernandez.servicio.LocalService;

import lombok.RequiredArgsConstructor;

/**
 * 
 * @author DFB
 *
 */

@Component
@RequiredArgsConstructor
public class InitData {
	
	private final InmobiliariaService inmoService;
	private final LocalService localService;
	
	/**
	 * Método para rellenar datos de prueba
	 */
	@PostConstruct
	public void run() {
		
		
		Inmobiliaria inmo = new Inmobiliaria("PrimeraInmobiliaria","Calle Gran Poder","987654321","primeraInmo@gmail.com");
		Inmobiliaria inmo2 = new Inmobiliaria("SegundaInmobiliaria","Calle El Carpio","986547458","segundaInmo@gmail.com");
		List<Local>listaLocales = new ArrayList<Local>();
		
		Local l1 = new Local("Sevilla","Los Bermejales","Piso","Calle Londres, 2","Inmuebles de A4 CONSULTING","954301764",
				"gayala@a4consulting.es","https://fotos.imghs.net/h700//1005/157/1005_112619196157_1_2021020320024998904.jpg",
				"1","2","A4 consulting te presenta en exclusiva, apartamento a estrenar en Bermejales// bajo muy luminoso "
						+ "con techos altos, zona muy tranquila "
						+ "y con vistas despejadas al parque//salón amplio, dos dormitorios independientes, baño con plato "
						+ "de ducha y cocina americana perfectamente equipada// ubicación privilegiada, fácil aparcamiento, "
						+ "junto a barriada de Heliópolis,todo tipo de servicios: supermercados, centro comercial Lagoh, "
						+ "ambulatorio y hospital, centro deportivo Sadus, colegios y escuela infantil\r\n"
						+ "\r\n"
						+ "Honorarios inquilino: una mensualidad+IVA Índice de referencia de precios de alquiler: 0",
						LocalDate.of(1993, 9, 1),LocalDate.of(2021,5,12),44.0,650.0,0.0,false,inmo);
		
		Local l2 = new Local("Sevilla","Pino Montano","Piso","Calle Hortelanos","ESTUDIO PMONTANO-LOS OFICIOS, S.L.","954306856","seae8@tecnocasa.es"
				,"https://fotos.imghs.net/h700//1002/311/1002_TC280-376311_1_2021052012070931250.jpg",
				"1","3","Piso en Alquiler en Pino Montano.\r\n"
						+ "\r\n"
						+ "La vivienda totalmente reformada consta de 80 m2 distribuidos en 3 habitaciones, 1 baño, "
						+ "salón comedor con la terraza integrada en el salón y cocina con lavadero.\r\n"
						+ "\r\n"
						+ "Se quedaría amueblada y cuenta con aires acondicionados en cada habitación y en el salón.\r\n"
						+ "\r\n"
						+ "En el precio se incluye la comunidad y el agua.\r\n"
						+ "\r\n"
						+ "Magnífica zona para vivir, rodeado de numerosos servicios, todo tipo de comercios, varias "
						+ "lineas de autobús, comercios, colegios, zona ocio, etc.\r\n"
						+ "\r\n"
						+ "Se pide al inquilino últimas nóminas y contrato de trabajo..",LocalDate.of(1986, 4, 7),
						LocalDate.of(2021,5,12),81.0,600.0,0.0,false,inmo);
		
		Local l3 = new Local("Sevilla","Distrito Nervión","Piso","Avenida de Eduardo Dato, 24",
				"Inmuebles de LEXFINCA INMOBILIARIA","955935021",
				"lex8@lexfinca.es","https://fotos.imghs.net/h700//1018/539/1018_15571539_0_2021040619045947911.jpg",
				"1","2","Casi a estrenar, comunidad, agua e internet incluidos.Estupendo piso en alquiler, amueblado, "
						+ "en la mejor esquina de Nervión,consta de dos dormitorios, cocina amueblada y equipada con"
						+ " electrodomésticos nuevos, salón, cuarto de baño completo con dos lavabos,hall, pasillo distribuidor,"
						+ " gran terraza, excelentes calidades en carpintería de madera y aluminio, puerta de acceso a vivienda"
						+ " de seguridad, climatización , exterior, muy luminoso y ventilado, segunda planta con ascensor."
						+ " Magníficamente conectado con toda la ciudad con varias lineas de autobuses, parada de metro, "
						+ "estación de bicicletas municipales. Un auténtico privilegio a su alcance - Televisor Smart TV 50 "
						+ "Pulgadas - Climalit- Persianas automáticas. Disponible 1 de mayo",
						LocalDate.of(1997, 5, 23),LocalDate.of(2021,5,12),78.0,950.0,0.0,false,inmo2);

		Local l4 = new Local("Sevilla","San Gil","Piso","Calle Escoberos","Inmuebles de SOLHOGAR","954305245",
				"solhogar@solhogar.com","https://fotos.imghs.net/h700//1005/344/1005_42021993344_1_2020102719102489292.jpg",
				"1","1","Alquiler ático en La Macarena, Sevilla\r\n"
						+ "\r\n"
						+ "¿Te gustaría vivir en un Ático moderno y coqueto en pleno centro de Sevilla y muy cerca de la Macarena? ¡Ahora tienes la oportunidad!\r\n"
						+ "\r\n"
						+ "Precioso Ático acogedor y tranquilo en la zona más deseada de Sevilla. Se encuentra muy cerca del arco de la Macarena y a un pie de la Alameda. (Calle Resolana,Calle Feria, Parlamento de Andalucía, Torre de los Perdigones, Hospital Universitario Virgen de la Macarena, Calle Torneo.) Bancos, Supermercados, Guarderías, Farmacias, Servicios Médicos, y todos los servicios a un paso.\r\n"
						+ "\r\n"
						+ "Se localiza en la calle Escoberos, en un edificio sevillano de principios del s.XX. Tiene una entrada preciosa con rejas y azulejos. El edificio cuenta con 4 vecinos, uno por planta, y no dispone de ascensor.\r\n"
						+ "\r\n"
						+ "Este maravilloso Ático cuenta con 1 habitación amplia, techo con vigas de madera, espacioso salón con sofá-cama, cocina americana equipada con electrodomésticos, hermoso baño completo con placa de ducha y termo eléctrico. Está completamente amueblado con muebles modernos y su decoración cumple con las expectativas más altas. La azotea es comunitaria, teniendo acceso directo desde la planta 3, donde se sitúa el ático.\r\n"
						+ "\r\n"
						+ "La vivienda está impecable, para entrar a vivir.... Llámenos y venga a verlo, le encantará.\r\n"
						+ "\r\n"
						+ "Se pedirá la siguiente documentación laboral de las personas que figuren en el contrato de alquiler:\r\n"
						+ "Por cuenta ajena: 3 últimas nóminas, contrato de trabajo, DNI y vida laboral.\r\n"
						+ "Por cuenta propia: impuesto sobre la renta, 3 últimos trimestres, 3 últimos recibos de pago a la seguridad social y vida laboral.\r\n"
						+ "\r\n"
						+ "A petición de la parte propietaria no se admiten animales de compañía.\r\n"
						+ "\r\n"
						+ "C.E.E.: E (Documentación Dto. 218/2005 de inf. a consumidores y usuarios de la Junta de Andalucía a disposición de arrendatarios.Honorarios profesionales 1 mensualidad + IVA). Índice de referencia de precios de alquiler: 0",
						LocalDate.of(2016, 6, 12),LocalDate.of(2021,5,12),50.00,550.00,0.0,false,inmo);
		
		Local l5 = new Local("Sevilla","Distrito Macarena","Piso","Avenida Sánchez Pizjuan","Inmuebles de Elcuarto Inmobiliaria",
				"954305126","info@elcuartoinmbiliaria.com","https://fotos.imghs.net/h700//522509/14187042166.522509/522509_14187042166_1_20210520094813520.jpg",
				"1","1","Magnífica vivienda situada en Las Golondrinas, zona Macarena.\r\n"
						+ "El inmueble que dispone de 79 m2, consta de 2 amplios dormitorios muy luminosos, uno de ellos con armario empotrado, salón-comedor con terraza incorporada que da directo a la avenida Sánchez Pizjuán, soleado de mañana y muy luminoso, cocina con despensa, vitrocerámica y gas butano y baño totalmente reformado con placa de ducha y armario empotrado para almacenaje.\r\n"
						+ "Vivienda amplia y luminosa, muy bien situada, recién pintada y en muy buen estado.\r\n"
						+ "Con una ubicación inmejorable, a menos de 5 minutos andando de las facultades de medicina, enfermería, podología, odontología y fisioterapia, cercano al paseo del Guadalquivir. A 300 metros del hospital de La Macarena y a tan solo 15 minutos andando del centro.\r\n"
						+ "Muy bien comunicado con varias salidas a carreteras y varias líneas de autobús. Con todo lo necesario para el día a día a mano, supermercados, farmacias, colegios, hospital. . .",
				LocalDate.of(2016, 6, 2),LocalDate.of(2021,5,12),50.00,550.00,0.0,false,inmo);
		
		Local l6 = new Local("Sevilla","Distrito Bellavista-La Palmera","Piso","Glorieta de Letonia",
				"Inmuebles de A4 CONSULTING","954301764","gayala@a4consulting.es",
				"https://fotos.imghs.net/h700//1005/157/1005_113996186157_1_2021030719031511255.jpg",
				"3","3","Te presentamos un magnífico piso en RESIDENCIAL PALMERA, posiblemente la mejor urbanización de Los Bermejales //\r\n"
						+ "La vivienda con magníficas calidades tiene un amplio hall con armario a su derecha y a aseo convertido en habitación en donde ubicamos lavadora, secadora y zona de almacenaje\r\n"
						+ "Gran salón-comedor de 34m2 con amplio ventanal // Cocina de diseño italiana abierta al salón // Tres dormitorios uno de ellos tipo suite con baño incorporado y otro baño más, todas las habitaciones tienen mosquiteras // Doble sistema de calefacción: Bomba de frío y calor centralizada y eléctrica y un sistema sde Calefacción central de gas programable por circuito de agua caliente //\r\n"
						+ "Vivienda muy luminosa y tranquila // Tres piscinas // Pista de Paddel //\r\n"
						+ "Zona recreo infantil // Ambiente muy familiar // Urbanización cerrada //\r\n"
						+ "Vigilada 24 horas // Conserjería //\r\n"
						+ "Dos locales comunitarios para celebración de cumpleaños y fiestas\r\n"
						+ "Se acaba de pintar vivienda y terraza.\r\n"
						+ "Rodeado de los mejores servicios: Supermercados, Centro de Salud,\r\n"
						+ "\r\n"
						+ "Si tienes vivienda en venta, te ayudamos a venderla,\r\n"
						+ "\r\n"
						+ "Si le hace falta valoración o asesoramiento en la venta de su vivienda le podemos ayudar //\r\n"
						+ "\r\n"
						+ "En nuestra inmobiliaria encontrará un equipo de profesionales que le acompañará en todas las fases de la compra-venta del inmueble, valoración del mismo, financiación, preparación de documentos, asistencia en notaría.\r\n"
						+ "\r\n"
						+ "Otra forma de trabajar, pasión por lo que hacemos.\r\n"
						+ "Gastos de notaría, registro e impuestos por la Compra NO Incluidos en el Precio.\r\n"
						+ "A disposición Documentación s/ Dto. 218/2005 de Junta Andalucía.)",LocalDate.of(2003, 3, 14),LocalDate.of(2021,5,12),129.0,0.0,375000.0,true,inmo2);
		
		Local l7 = new Local("Sevilla","Santa Cruz","Casa","Plaza de los Venerables",
				"Inmuebles de SAENZ DE TEJADA INMOBILIARIA","954307286","satein8@saenztejada.es","https://fotos.imghs.net/h700//515011/10891904262.515011/515011_10891904262_1_20210119120704409.jpg",
				"3","4 o más","Planta baja en casa señorial rehabilitada en pleno barrio de santa cruz\r\n"
						+ "\r\n"
						+ "Apto para la explotación con fines turísticos, sede empresarial, oficina.\r\n"
						+ "\r\n"
						+ "Existen dos posibilidades de alquiler:\r\n"
						+ "-planta baja 260m² para uso comercial o turístico (3.000€ mes)\r\n"
						+ "-inmueble completo 546m², (10.000€ mes)\r\n"
						+ "\r\n"
						+ "Situado en pleno centro de sevilla junto al hospital de los venerables, en el barrio de santa cruz, con acceso de tráfico rodado hasta la puerta del inmueble. Por su situación se encuentra a 5 minutos de cualquier punto de interés del casco histórico. Cuenta en sus alrededores con la mayor oferta turística, comercial y gastronómica de la ciudad.\r\n"
						+ "\r\n"
						+ "Se trata de un inmueble completamente rehabilitado, manteniendo materiales nobles originales del inmueble respetando el estilo de la construcción. Cuenta con calidades y elementos singulares como son: suelos de mármol, gran altura de techos con artesanados de madera, dos patios con montera acristalada, chimenea, etc.\r\n"
						+ "\r\n"
						+ "La vivienda se distribuye en torno a dos patios con montera acristalada, proporcionando gran amplitud y luminosidad a todas sus estancias.\r\n"
						+ "\r\n"
						+ "El inmueble se distribuye de la siguiente manera:\r\n"
						+ "Planta baja: hall entrada con acceso a dos amplios patios distribuidores, 6 habitaciones, 2 baños comunes y un baño en suite.",LocalDate.of(1990, 1, 17),LocalDate.of(2021,5,12),260.0,2000.0,0.0,false,inmo2);
		
		Local l8 = new Local("Sevilla","El Viso del Alcor","Casa","Calle Francia","Inmuebles de IMAISON","954305074",
				"ima8@imaison.es","https://fotos.imghs.net/h700//517074/7510450054.517074/517074_7510450054_1_20200908101750324.jpg",
				"2","4 o más","¿Quieres vivir en una casa y no la encuentras?\r\n"
						+ "\r\n"
						+ "¿Cansado de buscar?\r\n"
						+ "\r\n"
						+ "¡PARA! Te presentamos tú casa, la casa que siempre has querido tener.\r\n"
						+ "\r\n"
						+ "Ya no es un sueño, es una REALIDAD!\r\n"
						+ "\r\n"
						+ "Te presentamos casa adosada de 127 m2 construidos con cochera abierta, patio trasero de 30 m2 y terraza en planta alta.\r\n"
						+ "\r\n"
						+ "Entramos y nos encontramos con un espacio abierto, pudiéndose habilitar como cochera o porche delantero, donde poder pasar buenas veladas con la familia y amigos.\r\n"
						+ "\r\n"
						+ "Pasamos a la casa y nos espera un recibidor amplio y luminoso que nos da paso al resto de las estancias de la planta baja. La completamos con salón, habitación, baño completo, cocina, lavadero, patio y trastero. Destacar la cocina, completamente equipada con muebles lacados en blanco y encimera de granito con entrada directa al patio trasero. Éste último equipado con toldos.\r\n"
						+ "\r\n"
						+ "Subimos a la planta alta y nos encontramos con tres habitaciones, baño completo y terraza. Una de las habitaciones convertida en vestidor, equipado todo con muebles lacados en blanco y armario empotrado.\r\n"
						+ "\r\n"
						+ "No debemos dejar atrás las calidades de la vivienda, muy importante para una estancia agradable y acogedora. Mencionamos el suelo porcelánico, las puertas de madera color blanco, ventanas de aluminio con climalit, placas solares con doble pantalla, toldos patio trasero, vestidor completamente equipado, aire acondicionado salón y dormitorio principal.\r\n"
						+ "\r\n"
						+ "REQUISITOS:\r\n"
						+ "\r\n"
						+ "No se admiten mascotas.\r\n"
						+ "\r\n"
						+ "Entrega de doble fianza.\r\n"
						+ "\r\n"
						+ "Presentación de documentación.",LocalDate.of(2005, 11, 12),LocalDate.of(2021,5,12),127.0,650.0,0.0,false,inmo);
		
		Local l9 = new Local("Sevilla","Castilleja de Guzmán","Casa","Calle Real","Inmuebles de SOLHOGAR","954 308 903",
				"solhogar@solhogar.com","https://fotos.imghs.net/h700//1005/344/1005_113794853344_1_2021022622023733363.jpg",
				"3","3","Venta casa Castilleja de Guzmán (Sevilla)\r\n"
						+ "\r\n"
						+ "¡Hola futuros propietarios! Os presentamos esta casa situada en el centro de Castilleja de Guzmán. Es una casa adosada de esquina con 108 m2 construidos, repartidos en 2 plantas. Cuenta también con dos estupendos patios (delantero y trasero) para disfrutar con toda la familia.\r\n"
						+ "\r\n"
						+ "Castilleja de Guzmán es un pueblo del Aljarafe sevillano. Se encuentra a menos de 7 Km de la capital, y tiene muy buena comunicación con los pueblos vecinos (Castilleja de la Cuesta, Camas, Valencina de la Concepción o Gines). Desde el mismo pueblo de Castilleja de Guzmán sale un carril bici, por el cual puedes llegar a otros pueblos del Aljarafe viendo bonitos paisajes.\r\n"
						+ "\r\n"
						+ "La casa nos recibe con un bonito patio de entrada, le sigue el hall recibidor, amplio salón-comedor con vistas al patio delantero, un aseo, un cómodo armario aprovechando el hueco de escalera, y una amplia y luminosa cocina con acceso al patio trasero de unos 11 m2.\r\n"
						+ "En la primera planta encontraremos, 3 habitaciones y 2 baños. El dormitorio principal es tipo suite, con baño privado, y con un acogedor balcón con vistas a la calle.\r\n"
						+ "\r\n"
						+ "El patio trasero cuenta con una zona de trastero/lavadero (de unos 4,5 m2), muy amplia y práctica para guardar variedad de enseres y para la zona de lavadora.\r\n"
						+ "\r\n"
						+ "Gracias a una mejora, se amplió el salón y la cocina con una habitación que había en planta baja, lo que hace tener mayor amplitud y comodidad en dos de las estancias más importantes de la casa.\r\n"
						+ "\r\n"
						+ "Si busca una casa, en un pueblo tranquilo y a buen precio, esta es la suya. ¡¡Gran oportunidad!!\r\n"
						+ "\r\n"
						+ "CEE: E. Informamos a nuestros clientes que el precio de venta no incluye lo siguiente: Honorarios de la agencia inmobiliaria, impuestos (el Impuesto de Transmisiones Patrimoniales, I.V.A. o A.J.D., en su caso), otros gastos de la compraventa (gastos de registro de la Propiedad, Notaría, gestoría ni de posible financiación). Documento F.I.A. a disposición del consumidor según Decreto 218/2005 Junta de Andalucía.",LocalDate.of(1994, 9, 20),LocalDate.of(2021,5,12),108.0,0.0,140000.0,true,inmo);
		
		Local l10 = new Local("Sevilla","Palomares del Río","Chalet","Calle de la Estrella Polar",
				"Inmuebles de AREA BROKERS","954303392","comercial@areabrokers.es","https://fotos.imghs.net/h700//517788/10867028544.517788/517788_10867028544_1_20210128114617323.jpg",
				"2","3","Te ofrecemos la oportunidad de vivir en este maravilloso Chalet Independiente, de construcción moderna, en zona residencial La Estrella de Palomares del Río, por su ubicación al estar cerca de supermercados, colegio e instituto, y fácil acceso a SE-40 y carretera de Coria lo hacen irresistible.\r\n"
						+ "\r\n"
						+ "Entramos en la parcela de esquina, y de 571 m2 totalmente ajardinada y con piscina propia, garaje, y terraza donde disfrutar tanto los días de solito en invierno como el verano.\r\n"
						+ "\r\n"
						+ "Al pasar a la vivienda nos encontramos con un amplio salón con chimenea, cocina independiente, dos dormitorios, uno de ellos con un baño, y al subir a la primera planta disfrutaras de las vistas en un amplio dormitorio con vestidor y baño.\r\n"
						+ "\r\n"
						+ "Destacar de esta propiedad las ventanas de aluminio en madera, las puertas, los baños, la cocina, las placas solares, el aire acondicionado... todo ello hacen que usted entre directamente a vivir.\r\n"
						+ "\r\n"
						+ "Síguenos en tus redes sociales:\r\n"
						+ "Instagram: @areabrokersinmobiliaria\r\n"
						+ "Facebook: https://www.facebook.com/areabrokers\r\n"
						+ "\r\n"
						+ "Informamos a nuestros clientes que el precio de venta no incluye Honorarios de Agencia, Impuestos (Transmisiones Patrimoniales o I. V. A. y/o A. J. D. ), Gastos de registro de la Propiedad, Notaría, gestoría o de posible financiación.\r\n"
						+ "\r\n"
						+ "Documento D. I. A. a disposición del consumidor según Decreto 218/2005 Junta de Andalucía.",LocalDate.of(2000, 5, 23),LocalDate.of(2021,5,12),228.0,0.0,267000.0,true,inmo);
		
		Local l11 = new Local("Sevilla","Oromana (Alcalá de Guadaíra)","Chalet","Calle Olmo","Inmuebles de UMBRA",
				"950915861","oficina@umbra-inmo.com","https://fotos.imghs.net/h700//1005/084/1005_115659157084_1_2021042821041043337.jpg",
				"4 o más","4 o más","Un sueño de vivienda a tan solo 15 km del centro de Sevilla. Un sueño de casa para vivir y disfrutar de 1400m2 con 488m2 construido.\r\n"
						+ "\r\n"
						+ "Un Impresionante Chalet INDEPENDIENTE, para los amantes de los paraísos privados.\r\n"
						+ "\r\n"
						+ "UN HOGAR DE PELICULA con 5 hab, 1 preciosa piscina con gran espacio, 1 gimnasio, 1 salón de evento, 1 impresionante carpa para fiestas, 1 zona de jardín de barbacoa y chill out, 1 sala de juego, 1 chochera, 1 gran salon, 1 gran cocina, 2 baños, 2 aseos, 2 chimeneas y todo en una urbanización privada con vigilancia las 24 horas.\r\n"
						+ "\r\n"
						+ "Todo en la mejor zona de Alcalá de Guadaira con fácil entrada y salida a la autovía utrera/Sevilla.\r\n"
						+ "\r\n"
						+ "La vivienda está situada a 15 kilómetros de Sevilla a unos 20 minutos y a unos 10 kilómetros del Real Club de Pineda.\r\n"
						+ "\r\n"
						+ "Una vivienda preparada para hacerte feliz, Una vivienda para eventos con familiares, con amigos o solo con tu pareja.\r\n"
						+ "Un chalet independiente con una amplia parcela de 1400m2 que rodea la zona (norte-sur-este-oeste) de la vivienda.\r\n"
						+ "\r\n"
						+ "Disfruta de una vivienda lista para vivir...\r\n"
						+ "\r\n"
						+ "PLANTA Baja con suelo de baldosa (2 dormitorios):\r\n"
						+ "Distribuidor de entrada con escalera, amplio y luminoso salón con 3 grandes ventanas con orientación “Sur” y con acceso al jardín de la vivienda, 1 cocina totalmente equipada con orientación “Este” y con salida al jardín de la vivienda, Junto al salón encontramos un distribuidor con acceso a 1 dormitorio matrimonio con armario, 1 habitación single, 1 baño con placa y también comunica con la cocina.\r\n"
						+ "\r\n"
						+ "PLANTA 1 con suelo de mármol y (3 dormitorios):\r\n"
						+ "Frente a la puerta de entrada nos encontramos una preciosa escalera que nos comunica con la planta primera.\r\n"
						+ "1 gran dormitorio principal con chimenea y dos ventanas al jardín y piscina, pasillo vestidor que nos comunica con gran baño suite.\r\n"
						+ "1 dormitorio matrimonio con armario y ventanas a la piscina, 1 dormitorio matrimonio con armario con ventanas al Oeste, 1 preciosa terraza con vista a la piscina.\r\n"
						+ "\r\n"
						+ "ZONA JARDIN:\r\n"
						+ "-Zona de Cesped con porche, arboles, barbacoa, chillo ut y acceso a cuarto de juego en planta segunda.\r\n"
						+ "-Zona piscina rodeada de columnas decorativa, enlosada en su perímetro y también con zona de césped con 2 aseos.\r\n"
						+ "-Gran Carpa para evento 150 comensales cerca de la piscina.\r\n"
						+ "-Salón de eventos varios para 80 comensales u otros usos.\r\n"
						+ "-Garaje o cuarto de herramientas\r\n"
						+ "-Barra con pequeña cocina equipada\r\n"
						+ "-Sala de gimnasio o posible sala de invitados\r\n"
						+ "\r\n"
						+ "Comunicaciones:\r\n"
						+ "•15 km. Sevilla por autovía\r\n"
						+ "•7 km. Alcalá de Guadaira por autovía.\r\n"
						+ "•22 km. Aeropuerto de Sevilla.\r\n"
						+ "•88 km. Playa de Sanlúcar de Barrameda\r\n"
						+ "•7 km. Centro médico Alcalá de Guadaira\r\n"
						+ "•5 km. Hospital Dos Hermanas.\r\n"
						+ "\r\n"
						+ "\r\n"
						+ "LLAMANOS, Umbra trabaja para conseguir tus sueños.\r\n"
						+ "\r\n"
						+ "INFORMACION:\r\n"
						+ "Precio Actual SIN Impuestos: (7% I. T. P. Impuesto de transmisiones patrimoniales.\r\n"
						+ "Este precio no incluye honorarios de inmobiliaria, gastos de notaría y registrales.\r\n"
						+ "Los tipos aplicados son los más altos, pudiendo el comprador, por sus características, beneficiarse de algunas deducciones fiscales.\r\n"
						+ "El consumidor tiene derecho a copia del Documento Informativo Abreviado conforme Decreto 218/2005.",LocalDate.of(1980, 3, 13),LocalDate.of(2021,5,12),488.0,0.0,339000.0,true,inmo2);
		
		Local l12 = new Local("Sevilla","Gelves","Chalet","Calle Fernan Caballero, nº 10","Inmuebles de AREA BROKERS",
				"954303392","comercial@areabrokers.es","https://fotos.imghs.net/h700//517788/12595638306.517788/517788_12595638306_19_20210318114728063.jpg",
				"4 o más","4 o más","Superficie total 680 m², chalet superficie solar 1790 m², superficie útil 650 m², hab. individuales: 4, habitaciones dobles: 3, 5 baños, aire acondicionado (frío y calor), antigüedad entre 10 y 20 años, armarios empotrados (más de 2), calefacción (central), cocina, comedor, estado conservación: reformado, garaje (más de 2), orientación sur, piscina (propia), nivel energético de emisiones: C, 15,9, nivel energético de consumo: D, 91.",
				LocalDate.of(2007, 2, 11),LocalDate.of(2021,5,12),1790.0,0.0,2950000.0,true,inmo2);
		
		Local l13 = new Local("Sevilla","Guadalbullón(Sevilla)","Trastero","S. Bernardo-Menéndez Pelayo","Inmuebles de UMBRA","950915861","oficina@umbra-inmo.com","https://fotos15.apinmo.com/3025/11591274/3-1.jpg",
				"0","1","Cuarto trastero situado en la planta sótano de un edificio de uso residencial y ubicado en la zona de la Palmera-Heliópolis en el municipio de Sevilla. Tiene unos 5 m2 útiles aproximadamente.",LocalDate.of(2001, 5, 23),LocalDate.of(2021,5,12),9.0,50.0,0.0,false,inmo);
		
		Local l14 = new Local("Sevilla","Arenal","Trastero","Calle Radio Sevilla, 7","Inmuebles de LEXFINCA INMOBILIARIA","955935021","lex8@lexfinca.es","https://fotos15.apinmo.com/3025/5720666/3-1.jpg",
				"0","1","Zona Arjona, junto estación de autobuses Plaza de Armas. Magnifico trastero de 9 m2 construidos y 6,26 m2 útiles, en zona muy comercial",LocalDate.of(2002, 7, 17),LocalDate.of(2021,5,12),9.0,0.0,18000.0,true,inmo);
		
		Local l15 = new Local("Los Ángeles","Bel Air","Chalet","Stradella Rd","Inmuebles de LEXFINCA INMOBILIARIA","955935021",
				"lex8@lexfinca.es","https://e00-expansion.uecdn.es/assets/multimedia/imagenes/2017/01/24/14852469851902.jpg",
				"4 o más","4 o más","'The ONE' es una megamansión construida en Bel Air de 9600 metros cuadrados por el productor de cine y promotor inmobiliario Nile Niami, consta de 20 habitaciones, y más de 30 cuartos de baño,5 cocinas, seis salones, un spa, una sala fitness, dos bodegas de vino y champán, una sala de cine doméstico, un bar con bolera de 4 pistas, mesa de billar y un simulador de golf. Un helipuerto y 7 piscinas habiendo una exclusiva en el dormitorio principal y otra de agua salada.",
				LocalDate.of(2020, 2, 1),LocalDate.of(2021,5,12),9600.0,0.0,500000000.0,true,inmo);
		
		listaLocales.add(l1);
		listaLocales.add(l2);
		listaLocales.add(l3);
		listaLocales.add(l4);
		listaLocales.add(l5);
		listaLocales.add(l6);
		listaLocales.add(l7);
		listaLocales.add(l8);
		listaLocales.add(l9);
		listaLocales.add(l10);
		listaLocales.add(l11);
		listaLocales.add(l12);
		listaLocales.add(l13);
		listaLocales.add(l14);
		listaLocales.add(l15);
		inmoService.save(inmo);
		inmoService.save(inmo2);

		
		for (Local local : listaLocales) {
			localService.save(local);
		}
		
		
		
		
	}

}
