package com.salesianostriana.dam.proyectofinal_locales_danielfernandez.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Clase que modela los datos de una inmobiliaria
 * @author DFB
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Inmobiliaria {
	
	@Id
	@GeneratedValue
	private long id;
	
	private String nombre, direccion, telefono, email;
	
	/**
	 * 
	 * @param nombre
	 * @param direccion
	 * @param telefono
	 * @param email
	 */
	public Inmobiliaria(String nombre, String direccion, String telefono, String email) {
		super();
		this.nombre = nombre;
		this.direccion = direccion;
		this.telefono = telefono;
		this.email = email;
	}




	
	
	

}
